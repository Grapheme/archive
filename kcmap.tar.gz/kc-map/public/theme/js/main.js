var MenuLine = (function(){
	
	var init = function() {

	}

	var set = function() {

	}

	$(document).on('mouseover', '.nav-main a', function(){
		set();
	});

	$(document).on('mouseout', '.nav-main a', function(){
		set();
	});
})();