<?php

class KcObjectsTableSeeder extends Seeder{

    public function run(){

    }
}
