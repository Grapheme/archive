<?php

return array(

	'dashboard' => 'Главная',
	'pages'     => 'Страницы',
	'languages' => 'Языки',
	'users'     => 'Пользователи',
	'galleries' => 'Галереи',
	'settings' 	=> 'Настройки',
	'editing' 	=> 'Редактирование',
	'creating' 	=> 'Создание',
	'news' 		=> 'Новости',
	'articles' 	=> 'Статьи',
	'templates' => 'Шаблоны',
	'groups'	=> 'Группы',
	'downloads' => 'Загрузки',
	'catalog' => 'Каталог продукции',
	'catalogs' => 'Каталоги',
	'categories' => 'Категории продукции',
	'products' => 'Продукция',
	'manufacturers' => 'Производители',

	'i18n_news' => 'Новости',
	'i18n_pages' => 'Страницы',
);