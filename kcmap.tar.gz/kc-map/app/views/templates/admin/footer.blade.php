<footer id="footer">
	<div class="row bottom-fixed">
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 margin-left-15">
			Все права защищены &copy; 2014 <a href="http://monety.pto/">MONETY.PRO</a>
		</div>
		<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
			<p>Copyright &copy; Grapheme 2014</p>
		</div>
	</div>
</footer>