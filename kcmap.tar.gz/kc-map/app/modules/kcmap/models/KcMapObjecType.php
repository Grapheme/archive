<?php

class KcMapObjecType extends \Eloquent {

    protected $table = 'kcmap_objects_types';

    protected $fillable = array('title','marker','color');
}