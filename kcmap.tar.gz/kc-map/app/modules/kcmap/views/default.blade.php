<div class="map-wrapper clearfix">
    <div id="map"></div>
 </div>