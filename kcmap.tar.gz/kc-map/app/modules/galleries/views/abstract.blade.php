
	<div class="egg-dropzone dropzone" data-gallery_id="{{ $gallery->id }}"></div>
