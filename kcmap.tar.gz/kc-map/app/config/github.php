<?php

return array(
    'active'            => TRUE,
    'test_mode_key'     => 'xBh4Wy7Y0Jbdmr97QTogVvMOirn2AOgq',
    'post_data'         => array(),
    'git_path'          => '/usr/bin/',
    'remote'            => 'origin',
    'branch'            => 'master',
    'repository_name'   => 'kc-map',
    'repository_id'     => 21685216,
    'user_group'        => 'rikardo',
    'user_name'         => 'rikardo',
    'set_log'           => TRUE,
    'directories'       => array('public/uploads','app/storage')
);