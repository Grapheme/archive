<?php

return array(

	'use_typekit' => FALSE,
	'use_analyrics' => FALSE,
	'use_googleapis' => FALSE,
	'use_googlefonts' => FALSE,
	'use_css_local' => TRUE,
	'use_scripts_local' => TRUE,
	
	'debug' => FALSE
);