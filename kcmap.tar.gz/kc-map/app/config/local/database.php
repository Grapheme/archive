<?php

return array(
	'connections' => array(
		'mysql' => array(
			'database'  => 'kc_map',
			'username'  => 'root',
			'password'  => '',
		),
	),
);