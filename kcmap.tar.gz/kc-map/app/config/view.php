<?php

return array(

	'paths' => array(__DIR__.'/../views', __DIR__.'/../modules'),
	#'paths' => array(__DIR__.'/../modules'),
	#'pagination' => 'pagination',
	'pagination' => 'pagination::slider-3',
);
