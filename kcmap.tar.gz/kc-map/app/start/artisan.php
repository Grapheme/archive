<?php

Artisan::add(new TruncateTables);
